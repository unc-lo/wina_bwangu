<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wina Bwangu - Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
			
            margin: 0;
            padding: 0;
            background: linear-gradient(to right,  #343a40 0%,  #343a40 100%);
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #343a40;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        h1 {
			color: #fff;
            text-align: center;
			
        }
		 h2 {
			color: #fff;
            text-align: center;
			
        }
        canvas {
            display: block;
            margin: 0 auto;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            font-family: Arial, sans-serif;
			  color: #fff;
        }
        th, td {
            font-family: Arial, sans-serif;
            border: 1px solid #fff;
            text-align: left;
            padding: 8px;
        }
        th {
            font-family: Arial, sans-serif;
            background-color:  #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #343a40;
        }
       
		    a .signup-button {
    display: inline-block;
    padding: 10px 20px;
    background-color: #fff;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    text-align: center;
    font-size: 16px;
    font-weight: bold;
}

a .signup-button:hover {
    background-color: #D2B48C;
}
</style>
</head>
<body>
    <div class="container">
        <h1>Wina Bwangu - Monthly Reports</h1>
		
        <h2>Transaction Details</h2>
        <table>
            <thead>
                <tr>
                    <th>Transaction ID</th>
                    <th>Mobile Booth</th>
                    <th>Location</th>
                    <th>Service</th>
					<th>RevenuePerKwacha</th>
                    <th>Transaction Amount</th>
                </tr>
            </thead>
            <tbody>
                      <?php
// Database connection
$db_hostname = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'mtms_db';

$conn = new mysqli($db_hostname, $db_username, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve transaction details from the database
$sql = "SELECT TransactionID, MobileBooth, Location, Service, RevenuePerKwacha, TransactionAmount FROM transactions_data";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["TransactionID"] . "</td>";
        echo "<td>" . $row["MobileBooth"] . "</td>";
        echo "<td>" . $row["Location"] . "</td>";
        echo "<td>" . $row["Service"] . "</td>";
        echo "<td>" . $row["RevenuePerKwacha"] . "</td>";
        echo "<td>" . $row["TransactionAmount"] . "</td>";
        echo "</tr>";
    }
} else {
    echo "No records found";
}

// Close the database connection
$conn->close();
?>



            </tbody>
        </table>

        <h2>Revenue and Service Progress</h2>
        <canvas id="lineChart" width="800" height="400"></canvas>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Data for the line chart (replace with actual data)
        var data = <?php echo json_encode($cumulativeRevenue); ?>;
        var ctx = document.getElementById('lineChart').getContext('2d');

        // Extract labels and data values
        var labels = Object.keys(data);
        var values = labels.map(function (label) {
            return data[label]['totalRevenue'];
        });

        var lineChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Total Revenue',
                    data: values,
                    fill: false,
                    borderColor: '#FF6384',
                    backgroundColor: '#FF6384',
                    pointBackgroundColor: '#FF6384',
                    pointRadius: 5,
                    pointHoverRadius: 10,
                }]
            },
            options: {
                responsive: true,
                scales: {
                    x: {
                        type: 'category',
                        labels: labels
                    },
                    y: {
                        beginAtZero: true
                    }
                },
                legend: {
                    display: true,
                    position: 'bottom'
                },
                title: {
                    display: true,
                    text: 'Revenue and Service '
                }
            }
        });
    </script>
</body>
</html>
