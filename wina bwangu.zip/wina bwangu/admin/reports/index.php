<?php
$db_hostname = 'localhost';
$db_username = 'root';
$db_password = '';
$db_name = 'mtms_db';

$conn = new mysqli($db_hostname, $db_username, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$serviceTotals = [];

// Query your database to calculate service totals
$sql = "SELECT Service, SUM(TransactionAmount) as TotalAmount FROM transactions GROUP BY Service";
$result = $conn->query($sql);

$totalSum = 0; // Variable to store the total sum of all TransactionAmount

while ($row = $result->fetch_assoc()) {
    $serviceTotals[$row['Service']] = $row['TotalAmount'];
    $totalSum += $row['TotalAmount'];
}

// Calculate proportions
$proportions = [];
foreach ($serviceTotals as $service => $totalAmount) {
    $proportions[$service] = $totalAmount / $totalSum;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pie Chart - Total Revenue by Service</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to right, #99004d 0%, #ff0080 100%);
    }

    .pie-chart-container {
        max-width: 600px;
        margin: 0 auto;
        background-color: #008080;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    h2 {
        color: #333;
    }

    /* Styles for the chart container */
    #pieChart {
        width: 100%;
        height: 300px;
    }

    /* Center the chart within its container */
    #pieChart {
        margin: 0 auto;
    }

    a.signup-button {
        display: inline-block;
        padding: 10px 20px;
        background-color: #FFD700;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        text-align: center;
        font-size: 16px;
        font-weight: bold;
    }

    a.signup-button:hover {
        background-color: #D2B48C;
    }
    </style>
</head>
<body>
    <div class="pie-chart-container">
        <h2>Pie Chart - Total Revenue Proportions by Service</h2>
        <div id="pieChart"></div>
    </div>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script>
    google.charts.load('current', { 'packages': ['corechart'] });
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Service');
        data.addColumn('number', 'Proportion');

        // Convert PHP array to JavaScript array
        var dataArray = [];
        <?php foreach ($proportions as $service => $proportion): ?>
            dataArray.push(['<?= $service ?>', <?= $proportion ?>]);
        <?php endforeach; ?>

        data.addRows(dataArray);

        var options = {
            title: 'Proportions of Total Revenue by Service',
            width: 400,
            height: 300,
            colors: ['#FF0000', '#0000FF', '#FFD700', '#008000', '#800080']
        };

        var chart = new google.visualization.PieChart(document.getElementById('pieChart'));

        chart.draw(data, options);
    }
    </script>
</body>
</html>
